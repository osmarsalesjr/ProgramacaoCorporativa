package utils;

import java.util.HashMap;
import java.util.Map;

public class RomanosUtil {
	
	private Map<String, Integer> tabela = new HashMap<>();
	
	
	public int converterString(String numero){
		
		numero = numero.toUpperCase();
		this.tabela.put("I", 1);
		this.tabela.put("V", 5);
		this.tabela.put("X", 10);
		this.tabela.put("L", 50);
		this.tabela.put("C", 100);
		this.tabela.put("D", 500);
		this.tabela.put("M", 1000);
		
		if (!this.tabela.containsKey(numero)){
			
			throw new IllegalArgumentException("SIMBOLO INVALIDO");
		}
		
		int retorno = this.tabela.get(numero);
		
		return retorno;
	}
}
