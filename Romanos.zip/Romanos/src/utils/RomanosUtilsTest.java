package utils;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RomanosUtilsTest {
	
	private RomanosUtil ru;
	
	@Before
	public void setUp(){
		
		this.ru = new RomanosUtil();
	}

	@Test
	public void deve_converter_simbolos_simples_validos() {
		
		assertEquals(1, ru.converterString("I"));
		assertEquals(5, ru.converterString("V"));
		assertEquals(10, ru.converterString("X"));
		assertEquals(50, ru.converterString("L"));
		assertEquals(100, ru.converterString("C"));
		assertEquals(500, ru.converterString("D"));
		assertEquals(1000, ru.converterString("M"));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void deve_falhar_com_simbolos_simples_invalidos() {
		
		ru.converterString("T");
		ru.converterString("N");
	}

}
